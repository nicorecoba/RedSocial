﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public enum EstadoSolicitud
    {
        pendiente_aprobacion = 0,
        aprobada = 1,
        rechazada = 2
    }
    //constructor
}
