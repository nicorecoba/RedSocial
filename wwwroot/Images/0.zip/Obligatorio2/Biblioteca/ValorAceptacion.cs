﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public enum ValorAceptacion
    {
        valorLike = 1,
        valorDislike = 2,
        valorPublico = 3
    }
    //constructor
}
